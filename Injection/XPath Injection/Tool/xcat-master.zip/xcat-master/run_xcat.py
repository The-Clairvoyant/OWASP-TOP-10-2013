from xcat import xcat

xcat.run()